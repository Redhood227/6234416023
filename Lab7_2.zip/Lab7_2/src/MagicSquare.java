public class MagicSquare {
    private final int[][] square;
    private final int n;
    int startColumns;
    int startRow;
    
    public MagicSquare(int n){
        this.n=n;
        square = new int[n][n];
        startRow = n-1;
        startColumns = n/2;
        for(int num=1; num<=n*n;){
            if (startRow == n && startColumns == n){
                startRow-=2;
                startColumns--;}
            else{
                if(startRow==n){
                    startRow=0;
            }
                if(startColumns==n){
                    startColumns=0;
            }
            }
            
            if(square[startRow][startColumns]!= 0){
                startRow-=2;
                startColumns--;
                continue;
            }
            
            else{
                    square[startRow][startColumns]=num++;
            }
            
            startRow++; startColumns++; 
             } 
        
        
}   public String toString(){
      String r = "";
      for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                r = r+square[i][j] + "\t";
            }r=r+"\n";
      }
      return r;
    }
    public static void main(String[] args) {
        MagicSquare a =new MagicSquare(5);
        System.out.println(a.toString());}
 
}