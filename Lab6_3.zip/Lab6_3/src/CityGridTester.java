public class CityGridTester {
    public static void main(String[] args) {
        CityGrid city = new CityGrid(10);
        int i = 0,maxStep=0,totalStep=0;
        while(i<10000){
            int step=0;
            while(step<1000 && city.isInCity()){
                city.walk();
                step++;
            }
            totalStep=totalStep+step;
            if(step>maxStep){
                maxStep=step;
            }
            city.reset();
            i++;
        }
        double avrStep = totalStep*0.0001;
        System.out.println("Average number of steps that a person can take and is still in the city: "+String.format("%.2f",avrStep));
        System.out.println("Maximum number of steps that a person can take and is still in the city: "+maxStep);
    }
    
}
