/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3_3;

/**
 *
 * @author asus
 */
public class CashRegister {
    private final double tax;
    private double balance;
    private double money;
    private double taxtotal;
    public CashRegister(double t)
    {
        tax=t;
    }
    public void recordPurchase(double purchase)
    {
        balance=balance+purchase;
    }
    public void recordTaxablePurchase(double taxpay)
    {
        taxtotal=taxtotal+(taxpay*(100+tax)/100);
        balance=balance+(taxpay*(100+tax)/100);
    }
    public double getTotalTax()
    {
        return taxtotal;
    }
    public void enterPayment(double payment)
    {
        money=money+payment;
    }
    public double giveChange()
    {
        double change=money-balance;
        balance=0;
        money=0;
        return change;
    }
}
