/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3_3;

/**
 *
 * @author asus
 */
public class CashRegisterTester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        CashRegister goods = new CashRegister(7);
        goods.recordPurchase(50);
        goods.recordPurchase(10);
        goods.recordTaxablePurchase(20);
        goods.enterPayment(100);
        System.out.println("Your change is "+goods.giveChange());
    }
    
}
