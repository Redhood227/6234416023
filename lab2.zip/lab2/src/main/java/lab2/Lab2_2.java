
package lab2;

public class Lab2_2 {
    public static void main(String[] args) {
        String s1 = "Hello, World!";
        String s2 = s1.replace("o", "*");
        String s3 = s2.replace("e", "o");
        String s4 = s3.replace("*", "e");
        System.out.println(s4);
    }
    
}
