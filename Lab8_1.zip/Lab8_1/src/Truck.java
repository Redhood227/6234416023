public class Truck extends Car {
    private final double weight;
    private final double M_weight;
    public Truck(double gas,double eff,double weight,double maxWeight){
        super(gas,eff);
        M_weight = maxWeight;
        if(M_weight>weight){
        this.weight = weight;}
        else{
        this.weight = maxWeight;
        }
    }
    @Override 
    public void drive(double distance){
        double usedGas;
        if(weight<1){
            usedGas = distance/efficiency ;
        }
        else if(weight<=10){
            usedGas = (distance/efficiency)*1.1;
        }
        else if(weight<=20){
            usedGas = (distance/efficiency)*1.2;
            
        }
        else{
            usedGas = (distance/efficiency)*1.3;
        }
        
        if(usedGas<=gas){
            gas=gas-usedGas;
        }
        else {
            System.out.println("You cannot drive too far, please add gas");
        }
    }
}
