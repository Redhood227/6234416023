import java.util.Random;
import java.util.Scanner;
public class Game {
    private int playerScore,comScore;
    private final int rock=0;
    private final int paper=1;
    private final int scissors=2;
    public void play(){
        Random com = new Random();
        while(playerScore-comScore<2&&comScore-playerScore<2)
        {
        System.out.print("Enter 0 for ROCK, 1 for PAPER, 2 for SCISSORS: ");
        Scanner p = new Scanner(System.in);
        if(p.hasNextInt()){
        int player = p.nextInt();
        int computer = com.nextInt(3);
            switch (player) {
                case rock:
                    System.out.println("You enter: ROCK");
                    switch (computer) {
                        case rock:
                            System.out.println("Computer: ROCK");
                            System.out.println("It's a tie.");
                            break;
                        case paper:
                            System.out.println("Computer: PAPER");
                            System.out.println("You lose!");
                            comScore++;
                            break;
                        case scissors:
                            System.out.println("Computer: SCISSORS");
                            System.out.println("You win!");
                            playerScore++;
                            break;
                    }       break;
                case paper:
                    System.out.println("You enter: PAPER");
                    switch (computer) {
                        case rock:
                            System.out.println("Computer: ROCK");
                            System.out.println("You win!");
                            playerScore++;
                            break;
                        case paper:
                            System.out.println("Computer: PAPER");
                            System.out.println("It's a tie.");
                            break;
                        case scissors:
                            System.out.println("Computer: SCISSORS");
                            System.out.println("You lose!");
                            comScore++;
                            break;
                    }       break;
                case scissors:
                    System.out.println("You enter: SCISSORS");
                    switch (computer) {
                        case rock:
                            System.out.println("Computer: ROCK");
                            System.out.println("You lose!");
                            comScore++;
                            break;
                        case paper:
                            System.out.println("Computer: PAPER");
                            System.out.println("You win!");
                            playerScore++;
                            break;
                        case scissors:
                            System.out.println("Computer: SCISSORS");
                            System.out.println("It's a tie.");
                            break;
                    }       break;
                default:
                    break;
            }
        }}
        if(comScore>playerScore){
            System.out.println("Too bad! You lose.");
        }
        else if(comScore<playerScore){
            System.out.println("Congrats! You win.");
        }
        System.out.println("User Score: "+playerScore);
        System.out.println("Computer score: "+comScore);
    }
}
