
package lab4_3;

import java.util.Scanner;

public class TimeIntervalTester {

    public static void main(String[] args) {
        System.out.print("Enter start time:");
        Scanner s = new Scanner(System.in);
        int start = s.nextInt();
        System.out.print("Enter end time:");
        Scanner e = new Scanner(System.in);
        int end = e.nextInt();
        TimeInterval time = new TimeInterval(start,end);
        System.out.println(time.getHours()+" hours "+time.getMinutes()+" minutes");
    }
    
}
