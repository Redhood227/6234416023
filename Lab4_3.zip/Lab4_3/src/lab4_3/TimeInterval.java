/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4_3;

/**
 *
 * @author asus
 */
public class TimeInterval {
    private final int starttime;
    private final int endtime;
    public TimeInterval(int start,int end){
    starttime = (start/100*60)+(start%100);
    endtime = (end/100*60)+(end%100);
}
    public int getHours() {
        int hours=(endtime-starttime)/60;
        return hours;
}
    public int getMinutes(){
        int minutes=(endtime-starttime)%60;
        return minutes;
    }
}
