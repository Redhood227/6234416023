
import java.awt.geom.Point2D;
import static java.lang.Double.NaN;

class Line {
    private final double m;
    private final double b;
    private final double x;
    public Line(double x, double y, double m){
        this.m = m;
        b=(m*(-1)*x)+y;
        this.x = NaN;
    }
    public Line(double x1, double y1, double x2, double y2){
        m=(y2-y1)/(x2-x1);
        b=((x2*y1)-(x1*y2))/(x2-x1);
        x=NaN;
    }
    public Line(double m, double b){
        this.m = m;
        this.b = b;
        x=NaN;
    }
    public Line(double a){
        m=NaN;
        b=NaN;
        this.x=a;
    }
    public boolean isParallel(Line line){
        return this.m == line.m;
    }
    public boolean equals(Line line){
        return this.m == line.m && this.b == line.b ;
    }
    public boolean isIntersect(Line line){
        return this.m != line.m;
        }
    public Point2D.Double getIntersectionPoint(Line line){
        Point2D.Double ans = new Point2D.Double();
        if(Double.isFinite(line.m) && Double.isNaN(this.m)){
            double xi=this.x;
            double yi=(line.m*xi)+line.b;
            ans.setLocation(xi,yi);
        }
        else if(Double.isFinite(this.m) && Double.isNaN(line.m)){
            double xi=line.x;
            double yi=(this.m*xi)+this.b;
            ans.setLocation(xi,yi);
        }
        else if(this.m != line.m){
            double xi=(line.b-this.b)/(this.m - line.m);
            double yi=(line.m*xi)+line.b;
            ans.setLocation(xi,yi);
        }
        else if(this.m == line.m && this.b == line.b){
            double inf = Double.POSITIVE_INFINITY;
            ans.setLocation(inf,inf);
        }
        return ans;
    }
}
