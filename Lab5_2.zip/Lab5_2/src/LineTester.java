public class LineTester {
    public static void main(String[] args) {
    Line l1 = new Line(1,-24);
    Line l2 = new Line(29,5,53,29);
    System.out.println("Are the two lines equals?: "+l1.equals(l2));
    System.out.println("Are the two lines parallel?: "+l1.isParallel(l2));
    System.out.println("Do the two lines intersect?: "+l1.isIntersect(l2));
    if(l1.isIntersect(l2)){
        System.out.println("Point of intersection: "+String.format("%.2f",l1.getIntersectionPoint(l2).x)+","+String.format("%.2f",l1.getIntersectionPoint(l2).y));
    }
    }
}
