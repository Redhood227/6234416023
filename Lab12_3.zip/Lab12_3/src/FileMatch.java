
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.Scanner;


public class FileMatch {

    public static void main(String[] args) {
        ArrayList<AccountRecord> accRec = new ArrayList<>();
        ArrayList<TransactionRecord> transRec = new ArrayList<>();
        try(Scanner scanner = new Scanner(new File("C:\\Users\\asus\\Documents\\NetBeansProjects\\Lab12_3\\src\\master.txt"))){
            while(scanner.hasNextLine()){
            String[] rec = scanner.nextLine().split(" ");
            int accno = Integer.parseInt(rec[0]);
            String name = rec[1]+" "+rec[2];
            double balance = Double. parseDouble(rec[3]);
            AccountRecord acc = new AccountRecord(accno,name,balance);
            accRec.add(acc);
            }
        }
        catch(FileNotFoundException ex){
            System.out.println(ex);
        }
        
          try(Scanner scanner = new Scanner(new File("C:\\Users\\asus\\Documents\\NetBeansProjects\\Lab12_3\\src\\trans.txt"))){
            while(scanner.hasNextLine()){
            String[] rec = scanner.nextLine().split(" ");
            int accno = Integer.parseInt(rec[0]);
            double amount = Double. parseDouble(rec[1]);
            TransactionRecord acc = new TransactionRecord(accno,amount);
            transRec.add(acc);
            }
        }
        catch(FileNotFoundException ex){
            System.out.println(ex);
        }
          accRec.forEach((accRec1) -> {
          transRec.forEach((transRec1) -> {
                  int accRecno = accRec1.getAcctNo();
                  int transRecno = transRec1.getAccNumber();
                  if (accRecno==transRecno) {
                      accRec1.combine(transRec1);
                  }
              });
        });
         String name;
        int AccNo;
        double Balance;
        int tranCnt;
        double all_balance=0;
        int cntNottrans=0;
        int accCnt=0;
           try{
               RandomAccessFile file2 = new RandomAccessFile("newMaster.dat","rw");
               for(AccountRecord accRec1 : accRec){
                   name = accRec1.getName();
                   AccNo = accRec1.getAcctNo();
                   Balance = accRec1.getBalance();
                   tranCnt = accRec1.getTransCnt();
                   file2.writeInt(AccNo);
                   while(name.length()<30){
                       name+=' ';
                   }
                   String sentence = name;
                   file2.writeChars(sentence);
                   file2.writeDouble(Balance);
                   file2.writeInt(tranCnt);
                   file2.writeChar('\n');
               }
               file2.seek(0);
           } catch(IOException e){
               System.out.println(e);
           }
        try{
            RandomAccessFile file3 = new RandomAccessFile("newMaster.dat","r");
            
            for (AccountRecord accRec1 : accRec) {
                file3.seek(file3.getFilePointer()+64);
                all_balance+=file3.readDouble();
                if(file3.readInt() == 0){cntNottrans++;}
                accCnt++;
                file3.seek(file3.getFilePointer()+2);
            }

        } catch (IOException e){
            System.out.println(e);
        } 
        System.out.println("Total Account Record : "+accCnt);
        System.out.println("Total Balance : "+all_balance);
        System.out.println("No transaction : "+cntNottrans+" account.");
    }
    
}
