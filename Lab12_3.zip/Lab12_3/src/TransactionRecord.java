public class TransactionRecord {
    private int acc_number;
    private double amount;
    public TransactionRecord(int acc_number,double amount){
        this.acc_number = acc_number;
        this.amount = amount;
    }
    public TransactionRecord(){
        
    }
    public void setAccNumber(int accnum){
        this.acc_number = accnum;
    }
    public void setAmount(double amount){
        this.amount = amount;
    }
    public int getAccNumber(){
        return acc_number;
    }
    public double getAmount(){
        return amount;
    }
}
