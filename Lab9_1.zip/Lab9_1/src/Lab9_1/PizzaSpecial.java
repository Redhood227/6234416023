package Lab9_1;
public class PizzaSpecial extends Pizza {
    private String special;
    public PizzaSpecial(String name,double p,String spc){
        super(name,p);
        special = spc;
    }
    public String toString(){
        return super.toString()+" special : "+special;
    }
}
