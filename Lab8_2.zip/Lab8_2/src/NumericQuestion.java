import static java.lang.Math.abs;
public class NumericQuestion extends Question {
    public NumericQuestion(){
        super();
    }
    public NumericQuestion(String text){
        super(text);
    }
    public boolean checkAnswer(String response){
        double numberRes = Double.valueOf(response);
        double numberAns = Double.valueOf(super.getAnswer());
        return abs(numberRes-numberAns)<0.01;
    }        
}
