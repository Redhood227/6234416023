public class PurseTester {
    public static void main(String[] args) {
        Purse a = new Purse();
        Purse b = new Purse();
        a.addCoin("Quarter");
        a.addCoin("Dime");
        a.addCoin("Nickel");
        a.addCoin("Dime");
        b.addCoin("Nickel");
        b.addCoin("Dime");
        b.addCoin("Dime");
        b.addCoin("Quarter");
        System.out.println("a = "+a.toString()); //test addcoin and toString.
        System.out.println("b = "+b.toString());
        
        System.out.println("a.sameContents(b) : "+a.sameContents(b)); //test  sameContents
        System.out.println("a.sameCoins(b) : " + a.sameCoins(b));//test  sameCoins
        
        a.reverse(); 
        System.out.println("reverse a = "+a.toString());  //test reverse
        
       
        a.transfer(b); //test transfer
        System.out.println("a after a.transfer(b) : "+a);       
        System.out.println("b after a.transfer(b) : "+b); 
        
        Purse c = new Purse();
        Purse d = new Purse();
        c.addCoin("Quarter");
        c.addCoin("Dime");
        c.addCoin("Nickel");
        c.addCoin("Quarter");
        d.addCoin("Quarter");
        d.addCoin("Dime");
        d.addCoin("Nickel");
        d.addCoin("Quarter");
        System.out.println("c = "+c.toString());
        System.out.println("d = "+d.toString());
        System.out.println("c.sameContents(d) : "+c.sameContents(d)); //test  sameContents
        System.out.println("c.sameCoins(d) : "+c.sameCoins(d));//test  sameCoins
        
        Purse e = new Purse();
        Purse f = new Purse();
        e.addCoin("Quarter");
        e.addCoin("Dime");
        e.addCoin("Nickel");
        f.addCoin("Nickel");
        f.addCoin("Quarter");
        System.out.println("e = "+e.toString());
        System.out.println("f = "+f.toString());
        System.out.println("e.sameContents(f) : "+e.sameContents(f)); //test  sameContents
        System.out.println("e.sameCoins(f) : "+e.sameCoins(f));//test  sameCoins
    }
    
}
