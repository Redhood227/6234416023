
import java.util.ArrayList;

public class Purse {
    private ArrayList<String> purse = new ArrayList<>();
    public void addCoin(String coinName){
        purse.add(coinName);
    }

    public String toString(){
        return "Purse"+purse.toString();
    }

    public ArrayList<String> reverse(){
        ArrayList<String> reverse = new ArrayList<>();
        for(int i = purse.size()-1; i>=0; i--){
            reverse.add(purse.get(i));
        }
        return purse = reverse;
    }
    public void transfer(Purse other){
        while (purse.size() > 0)
        {
            other.purse.add(purse.get(0));
            purse.remove(0);
        }
    }
    public boolean sameContents(Purse other){
        return this.purse.equals(other.purse);
    }
    public boolean sameCoins(Purse other){
        boolean same = false;
        for(int i =0; i<=this.purse.size()-1; i++){
            for(int n=0; n<=other.purse.size()-1; n++){
                same = this.purse.get(i).equals(other.purse.get(n)) ; 
                if(same==true) break;
                }if(same==false) break;
        }return same;
    }
}
